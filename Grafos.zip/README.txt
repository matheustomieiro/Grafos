{\rtf1\ansi\ansicpg1252\cocoartf1671\cocoasubrtf200
{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\froman\fcharset0 Times-Bold;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue233;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c93333;}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 PROJETOS - DISCIPLINA DE MODELAGEM COMPUTACIONAL EM GRAFOS\
	Professor: Thiago Alexandre Salgueiro Pardo{\field{\*\fldinst{HYPERLINK "https://bv.fapesp.br/pt/pesquisador/8520/thiago-alexandre-salgueiro-pardo/"}}{\fldrslt 
\f1\b\fs28 \cf2 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 \
}}\
Alunos:\
	\
	Daniel da Rocha Fr\'f3es - 10255956\
	Leandro Satoshi de Siqueira - 10893103\
	Nicolau - XXXXXXXX\
	Mateus Prado Santos - 10851707\
	Matheus Tomieiro de Oliveira - 10734630\
\
\
Observa\'e7\'f5es:\
\
	Cada pasta possui um comando Make para compilar e executar cada projeto.\
	No projeto Plagio, o arquivo teste.in dever\'e1 ser modificado, atribuindo a ele as duas senten\'e7as.\
}