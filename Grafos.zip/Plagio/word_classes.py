#Run to know all possible word classes
import nltk
nltk.help.upenn_tagset()
exit(0)
